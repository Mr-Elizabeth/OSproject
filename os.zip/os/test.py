from tkinter import *
from emv_interrogator import *
from emv_utils import*
import os
import hashlib
import time
import mysql.connector
import sqlite3
import tkinter.ttk as ttk
import tkinter.messagebox as tkMessageBox

mydb2 = mysql.connector.connect(
  host="localhost",
  user="root",
  passwd="",
  database="os"
) 
cardnum=""
#sql = "INSERT INTO test1 (name, lastname, idcard, id) VALUES (%s, %s  ,%s ,%s)"
#val = ("namasawee","meekrongbang","5577557601710529","5830300494")
#mydb2.cursor().execute(sql, val)
#mydb2.commit()

while(1) :
        day = int(input())
        a = ["week1","week2","week3","week4","week5","week6","week7","week8","week9","week10","week11","week12","week13","week14","week15","week16"]
        count = 0
        idCard=retcardnum()
        mycursor2 = mydb2.cursor()
        main()
        mycursor2.execute("SELECT id FROM test1 WHERE idcard ='"+idCard+"'")
        myresult2 = mycursor2.fetchall()
        for x in myresult2:
                count = count+1
        if count >= 1  :
                sql = "UPDATE test1 SET "+a[day]+" = 1 WHERE idcard ='"+idCard+"'"
                mycursor.execute(sql)
                mydb2.commit()
        else:
                print("Unknow")
        idCard = ""
        mycursor = mydb2.cursor()
        mycursor.execute("SELECT name,id,"+a[day]+" FROM test1")
        myresult = mycursor.fetchall()
        for x in myresult:
                print (x)
        
                
        

