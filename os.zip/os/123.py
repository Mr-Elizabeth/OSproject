from tkinter import *
from emv_interrogator import *
from emv_utils import *
import os
import hashlib
import time
import mysql.connector
import sqlite3
import tkinter.ttk as ttk
import tkinter.messagebox as tkMessageBox

mydb2 = mysql.connector.connect(
  host="localhost",
  user="root",
  passwd="",
  database="os"
) 
cardnum=""
#sql = "INSERT INTO std1 (name, idcard, id) VALUES (%s, %s  ,%s)"
sql = "DELETE * FROM std1"
val = ("kaew","5577557601580468","5930300984")
mydb2.cursor().execute(sql)
mydb2.commit()

#while(1) :
#        day = int(input())
#        a = ["week1","week2","week3","week4","week5","week6","week7","week8","week9","week10","week11","week12","week13","week14","week15","week16"]
#        count = 0
#        idCard=retcardnum()
#        mycursor2 = mydb2.cursor()
#        main()
#        mycursor2.execute("SELECT id FROM std1 WHERE idcard ='"+idCard+"'")
#        myresult2 = mycursor2.fetchall()
#        for x in myresult2:
#                count = count+1
#        if count >= 1  :
#                sql = "UPDATE std1 SET "+a[day]+" = 1 WHERE idcard ='"+idCard+"'"
#               mycursor.execute(sql)
#               mydb2.commit()
#        idCard = ""
mycursor = mydb2.cursor()
mycursor.execute("SELECT * FROM std1")
myresult = mycursor.fetchall()
for x in myresult:
        print (x)
time.sleep(5.0)
                
        

