aids = {
        
    'Visa credit or debit':'A0000000031010',
    'Visa Electron':'A0000000032010',
    'V PAY':'A0000000032020',
    '(Visa)Plus':'A0000000038010',
    'MasterCard credit or debit':'A0000000041010',
    'MasterCard[4]':'A0000000049999',
    'Maestro (debit card)':'A0000000043060',
    'Cirrus (interbank network)':'A0000000046000',
    'Maestro UK':'A0000000050001',
    'Solo':'A0000000050002',
    'American Express':'A00000002501',
    'Discover':'A0000001523010',
    'Interac Debit card':'A0000002771010',
    'Japan Credit Bureau':'A00000006510',
    'ATM card':'A0000000291010',
    'Dankort Debit card':'A0000001211010',
    'PagoBANCOMAT':'A0000001410001',
    'Banricompras Debito':'A0000001544442',
    'Girocard':'A0000003591010028001',
    'CB card':'A0000000421010'

}