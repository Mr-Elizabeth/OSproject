For studying and learning about EMV chip cards

libraries

sudo pip install requests==1.1.0

sudo pip install python-firebase

sudo apt install pcscd

sudo apt install python-pyscard

run

python osFirstPage.py
